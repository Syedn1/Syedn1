﻿Copy-Item "C:\Users\12517\Downloads\ush_output\ASMO_Boardroom_Main.ush" "C:\Program Files (x86)\Crestron\Simpl\Usrsplus\ASMO_Boardroom_Main.ush" -Force
Copy-Item "C:\Users\12517\Downloads\ush_output\Sony_BRAVIA_Display.ush" "C:\Program Files (x86)\Crestron\Simpl\Usrsplus\Sony_BRAVIA_Display.ush" -Force
Copy-Item "C:\Users\12517\Downloads\ush_output\AVER_CAM570_PTZ.ush" "C:\Program Files (x86)\Crestron\Simpl\Usrsplus\AVER_CAM570_PTZ.ush" -Force
Copy-Item "C:\Users\12517\Downloads\ush_output\Shure_MXA920_DSP.ush" "C:\Program Files (x86)\Crestron\Simpl\Usrsplus\Shure_MXA920_DSP.ush" -Force
