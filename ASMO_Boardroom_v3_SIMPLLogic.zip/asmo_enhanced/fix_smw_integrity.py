import re

smw_path = r"C:\Users\12517\Downloads\ASMO_Boardroom.smw"

with open(smw_path, 'r', encoding='ascii', errors='replace') as f:
    content = f.read()

# Split into blocks
blocks = re.split(r'(\[/?[^\]]*\])', content)

# We'll rebuild the file by editing specific blocks
lines = content.split('\n')

print(f"Total lines: {len(lines)}")

# === FIX 1: CP4 Ethernet Devices symbol (ObjTp=Sm H=7) ===
# Remove non-existent child references, keep only valid ones: 18, 402, 810-815, 820
# Current: mC=24, C1=404...C24=820
# Valid children: 18, 402, 810, 811, 812, 813, 814, 815, 820

old_sm7 = """ObjTp=Sm
H=7
SmC=6580
Nm=CP4 Ethernet Devices
ObjVer=1
SmVr=1234
DvH=260
PrH=1
CF=1
Cmn1=Ethernet Devices
mC=24
C1=404
C2=18
C3=384
C4=319
C5=338
C6=366
C7=337
C8=365
C9=356
C10=360
C11=361
C12=401
C13=359
C14=362
C15=363
C16=364
C17=402
C18=810
C19=811
C20=812
C21=813
C22=814
C23=815
C24=820"""

new_sm7 = """ObjTp=Sm
H=7
SmC=6580
Nm=CP4 Ethernet Devices
ObjVer=1
SmVr=1234
DvH=260
PrH=1
CF=1
Cmn1=Ethernet Devices
mC=9
C1=18
C2=402
C3=810
C4=811
C5=812
C6=813
C7=814
C8=815
C9=820"""

if old_sm7 in content:
    content = content.replace(old_sm7, new_sm7)
    print("FIX 1: Fixed CP4 Ethernet Devices (H=7) - removed 15 orphaned children")
else:
    print("FIX 1: WARNING - Could not find CP4 Ethernet Devices block to fix")

# === FIX 2: CP4 COM symbol (ObjTp=Sm H=8) ===
# Children 316, 317, 318 don't exist - set mC=0 and remove children
old_sm8 = """ObjTp=Sm
H=8
SmC=6581
Nm=CP4 COM
ObjVer=1
SmVr=1234
DvH=516
PrH=1
CF=2
Cmn1=COM Ports
mC=3
C1=316
C2=317
C3=318"""

new_sm8 = """ObjTp=Sm
H=8
SmC=6581
Nm=CP4 COM
ObjVer=1
SmVr=1234
DvH=516
PrH=1
CF=2
Cmn1=COM Ports
mC=0"""

if old_sm8 in content:
    content = content.replace(old_sm8, new_sm8)
    print("FIX 2: Fixed CP4 COM (H=8) - removed 3 orphaned children")
else:
    print("FIX 2: WARNING - Could not find CP4 COM block to fix")

# === FIX 3: CP4 IR symbol (ObjTp=Sm H=11) ===
# Children 357, 358 don't exist - set mC=0 and remove children
old_sm11 = """ObjTp=Sm
H=11
SmC=6584
Nm=CP4 IR
ObjVer=1
SmVr=1234
DvH=557
PrH=1
CF=2
Cmn1=IR Ports
mC=2
C1=357
C2=358"""

new_sm11 = """ObjTp=Sm
H=11
SmC=6584
Nm=CP4 IR
ObjVer=1
SmVr=1234
DvH=557
PrH=1
CF=2
Cmn1=IR Ports
mC=0"""

if old_sm11 in content:
    content = content.replace(old_sm11, new_sm11)
    print("FIX 3: Fixed CP4 IR (H=11) - removed 2 orphaned children")
else:
    print("FIX 3: WARNING - Could not find CP4 IR block to fix")

# === FIX 4: Split H=276 out of batch for XPanel slot ===
# Current batch: H=265.280,287.291,296.514
# Need to change to: H=265.275,277.280,287.291,296.514
# And remove "10" from the Ad list
# Then add a new block for H=276

# Find the batch line
old_batch_h = "H=265.280,287.291,296.514"
new_batch_h = "H=265.275,277.280,287.291,296.514"

# The Ad list - need to remove "10" from the comma-separated list
# Original Ad starts with: 05,06,07,08,09,0A,0B,0C,0D,0E,0F,10,11,...
# After removing 10: 05,06,07,08,09,0A,0B,0C,0D,0E,0F,11,...
old_ad_segment = "0D,0E,0F,10,11"
new_ad_segment = "0D,0E,0F,11"

if old_batch_h in content:
    content = content.replace(old_batch_h, new_batch_h)
    print("FIX 4a: Split H=276 out of batch")
else:
    print("FIX 4a: WARNING - Could not find batch to split")

if old_ad_segment in content:
    content = content.replace(old_ad_segment, new_ad_segment)
    print("FIX 4b: Removed Ad=10 from batch")
else:
    print("FIX 4b: WARNING - Could not find Ad segment to fix")

# Now add the new H=276 block right after the batch block
# The batch block ends with "]" and then "[" for H=281
old_after_batch = """DvVr=1234
Ad=05,06,07,08,09,0A,0B,0C,0D,0E,0F,11"""

# Find where this block ends and add H=276 after it
# Let's insert the new block between the batch and H=281
old_h281_start = """[
ObjTp=Dv
Nm=P4Ethernet
H=281"""

new_h276_plus_h281 = """[
ObjTp=Dv
Nm=P4Ethernet
H=276
PrH=260
ObjVer=1
SlC=565
DvF=Sl
DvVr=1234
Ad=10
mC=1
C1=900
]
[
ObjTp=Dv
Nm=P4Ethernet
H=281"""

if old_h281_start in content:
    content = content.replace(old_h281_start, new_h276_plus_h281)
    print("FIX 4c: Added H=276 device block for XPanel IP-ID 10")
else:
    print("FIX 4c: WARNING - Could not find insertion point for H=276")

# Write the fixed file
with open(smw_path, 'w', encoding='ascii', errors='replace') as f:
    f.write(content)

print("\nAll fixes applied. File saved.")

# Verify block balance
opens = content.count('\n[')
closes = content.count('\n[/')
print(f"Block opens (approx): {opens}")
print(f"Block closes (approx): {closes}")
