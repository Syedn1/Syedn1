"""
Generate proper USH files for the 4 ASMO Boardroom SIMPL+ modules.
USH files define the symbol interface (inputs, outputs, parameters) that
SIMPL Windows reads to populate the symbol pins.
"""
import os

USH_DIR = r"C:\Users\12517\Downloads\ush_output"
DEST_DIR = r"C:\Program Files (x86)\Crestron\Simpl\Usrsplus"
os.makedirs(USH_DIR, exist_ok=True)

# Common header/footer template
HEADER = """[BEGIN]
  Version=1
[END]
[BEGIN]
  ObjTp=FSgntr
  Sgntr=UserSPlus
  RelVrs=1
  IntStrVrs=1
  SPlusVrs=4.06.00
  CrossCplrVrs=1.3
[END]
[BEGIN]
  ObjTp=Hd
[END]
"""

EXCLUSIONS = "1,19,20,21,88,89,167,168,179,213,214,215,216,217,225,226,248,249,266,267,310,362,378,380,405,407,408,409,478,522,537,554,586,590,611,624,718,756,767,830,841,842,854,883,955,1032,1062,1079,1128,1129,1134,1140,1157,1158,1195,1199,1220,1221,1222,1223,1299,1348,1349,1439,1472,1473,1499,1746,1803,1975,2229,2354,2514,2523,2532,2706,2707,3235,3236,3427,3454,3567,3568,3601,3602,3708,3902,3903,3912,3918,3925,3926,4206,4207,"


def build_ush(name, usp_filename, hint, category,
              digital_inputs, analog_inputs, buffer_inputs,
              digital_outputs, analog_outputs, string_outputs,
              string_params, int_params):
    """Build a complete USH file string."""

    lines = [HEADER.rstrip()]

    # Build the Symbol section
    sym = []
    sym.append("[BEGIN]")
    sym.append(f"  ObjTp=Symbol")
    sym.append(f"  Exclusions={EXCLUSIONS}")
    sym.append(f"  Exclusions_CDS=5")
    sym.append(f"  Inclusions_CDS=6,7")
    sym.append(f"  Name={name}")
    sym.append(f"  SmplCName={usp_filename}")
    sym.append(f"  Code=1")

    # Digital inputs (list 1 inputs)
    for i, cue in enumerate(digital_inputs, 1):
        sym.append(f"  InputCue{i}={cue}")
        sym.append(f"  InputSigType{i}=Digital")

    # Digital outputs (list 1 outputs)
    for i, cue in enumerate(digital_outputs, 1):
        sym.append(f"  OutputCue{i}={cue}")
        sym.append(f"  OutputSigType{i}=Digital")

    # List 2 inputs: analog first, then buffer/serial
    list2_in = []
    for cue in analog_inputs:
        list2_in.append((cue, "Analog"))
    for cue in buffer_inputs:
        list2_in.append((cue, "Serial"))

    for i, (cue, sigtype) in enumerate(list2_in, 1):
        sym.append(f"  InputList2Cue{i}={cue}")
        sym.append(f"  InputList2SigType{i}={sigtype}")

    # List 2 outputs: analog first, then string
    list2_out = []
    for cue in analog_outputs:
        list2_out.append((cue, "Analog"))
    for cue in string_outputs:
        list2_out.append((cue, "Serial"))

    for i, (cue, sigtype) in enumerate(list2_out, 1):
        sym.append(f"  OutputList2Cue{i}={cue}")
        sym.append(f"  OutputList2SigType{i}={sigtype}")

    # Parameters
    all_params = []
    # First param is always [Reference Name]
    sym.append(f"  ParamCue1=[Reference Name]")
    param_idx = 2
    for p in string_params:
        all_params.append(param_idx)
        sym.append(f"  ParamCue{param_idx}={p}")
        sym.append(f"  ParamSigType{param_idx}=String")
        param_idx += 1
    for p in int_params:
        all_params.append(param_idx)
        sym.append(f"  ParamCue{param_idx}={p}")
        sym.append(f"  ParamSigType{param_idx}=Constant")
        param_idx += 1

    # Variable I/O counts (all zero - no variable slots)
    sym.append(f"  MinVariableInputs=0")
    sym.append(f"  MaxVariableInputs=0")
    sym.append(f"  MinVariableInputsList2=0")
    sym.append(f"  MaxVariableInputsList2=0")
    sym.append(f"  MinVariableOutputs=0")
    sym.append(f"  MaxVariableOutputs=0")
    sym.append(f"  MinVariableOutputsList2=0")
    sym.append(f"  MaxVariableOutputsList2=0")
    sym.append(f"  MinVariableParams=0")
    sym.append(f"  MaxVariableParams=0")
    sym.append(f"  Expand=expand_separately")
    sym.append(f"  Expand2=expand_separately")
    sym.append(f"  ProgramTree=Logic")
    sym.append(f"  SymbolTree={category}")
    sym.append(f"  Hint={hint}")
    sym.append(f"  PdfHelp=")
    sym.append(f"  HelpID= ")
    sym.append(f"  Render=4")
    sym.append(f"  Smpl-C=16")
    sym.append(f"  CompilerCode=-48")
    sym.append(f"  CompilerParamCode=27")
    sym.append(f"  CompilerParamCode5=14")

    # NumFixedParams = total param count (including [Reference Name])
    total_params = 1 + len(string_params) + len(int_params)
    sym.append(f"  NumFixedParams={total_params}")
    # Pp entries for each parameter
    for i in range(1, total_params + 1):
        sym.append(f"  Pp{i}={i}")
    sym.append(f"  MPp={total_params}")

    sym.append(f"  NVStorage=10")
    sym.append(f"  ParamSigType1=String")
    sym.append(f"  SmplCInputCue1=o#")
    sym.append(f"  SmplCOutputCue1=i#")
    sym.append(f"  SmplCInputList2Cue1=an#")
    sym.append(f"  SmplCOutputList2Cue1=ai#")

    # SPlus2CompiledName
    compiled_name = "S2_" + usp_filename.replace(".usp", "")
    sym.append(f"  SPlus2CompiledName={compiled_name}")
    sym.append(f"  SymJam=NonExclusive")
    sym.append(f"  FileName={usp_filename.replace('.usp', '.ush')}")
    sym.append(f"  SIMPLPlusModuleEncoding=0")
    sym.append("[END]")

    lines.append("\n".join(sym))

    # Dp blocks - one for each parameter
    for i in range(1, total_params + 1):
        dp = []
        dp.append("[BEGIN]")
        dp.append(f"  ObjTp=Dp")
        dp.append(f"  H={i}")
        dp.append(f"  Tp=1")
        if i == 1:
            dp.append(f"  NoS=False")
        else:
            dp.append(f"  HD=False")
            dp.append(f"  Sgn=0")
            dp.append(f"  Lng=False")
            dp.append(f"  NF=63")
            dp.append(f"  NoS=True")
            dp.append(f"  DNF=1")
            dp.append(f"  VVS=0")
        dp.append("[END]")
        lines.append("\n".join(dp))

    return "\n".join(lines) + "\n"


# ============================================================================
# Module 1: ASMO_Boardroom_Main
# ============================================================================
main_di = [
    "System_Power_Toggle",
    "Disp1_Power_On", "Disp1_Power_Off",
    "Disp1_Src1", "Disp1_Src2", "Disp1_Src3",
    "Disp1_Src4", "Disp1_Src5", "Disp1_Src6",
    "Disp2_Power_On", "Disp2_Power_Off",
    "Disp2_Src1", "Disp2_Src2", "Disp2_Src3",
    "Disp2_Src4", "Disp2_Src5", "Disp2_Src6",
    "Matrix_Mirror", "Matrix_Independent", "Matrix_Extend",
    "Lift_Deploy", "Lift_Retract",
    "Cam1_Select", "Cam2_Select", "Cam_AutoTrack",
    "Cam_Pan_Left", "Cam_Pan_Right",
    "Cam_Tilt_Up", "Cam_Tilt_Down",
    "Cam_Zoom_In", "Cam_Zoom_Out",
    "Cam_Focus_Far", "Cam_Focus_Near",
    "Cam_Preset_1", "Cam_Preset_2", "Cam_Preset_3", "Cam_Preset_4",
    "Cam_Preset_Save",
    "Mic1_Mute_Toggle", "Mic2_Mute_Toggle",
    "Zone1_Toggle", "Zone2_Toggle",
    "All_Mute_Toggle", "Net_Mute_Btn_Toggle",
    "Audio_Preset_Meeting", "Audio_Preset_Pres",
    "Audio_Preset_VCall", "Audio_Preset_Mute",
    "VC_Join_Btn", "VC_Leave_Btn",
    "VC_Mic_Toggle", "VC_Cam_Toggle", "VC_Share_Toggle",
]  # 53

main_ai = ["Master_Volume_Level", "Mic1_Gain_Level", "Mic2_Gain_Level"]  # 3
main_bi = []  # 0

main_do = [
    "System_On_FB",
    "Disp1_On_FB", "Disp1_Off_FB",
    "Disp1_Src1_FB", "Disp1_Src2_FB", "Disp1_Src3_FB",
    "Disp1_Src4_FB", "Disp1_Src5_FB", "Disp1_Src6_FB",
    "Disp2_On_FB", "Disp2_Off_FB",
    "Disp2_Src1_FB", "Disp2_Src2_FB", "Disp2_Src3_FB",
    "Disp2_Src4_FB", "Disp2_Src5_FB", "Disp2_Src6_FB",
    "Cam1_Active_FB", "Cam2_Active_FB", "Cam_Track_FB",
    "Mic1_Mute_FB", "Mic2_Mute_FB",
    "Zone1_On_FB", "Zone2_On_FB",
    "All_Mute_FB", "Net_Mute_FB",
    "VC_InCall_FB", "VC_Mic_FB", "VC_Cam_FB",
]  # 29

main_ao = ["Master_Vol_Out", "Mic1_Gain_Out", "Mic2_Gain_Out", "Cam_Speed_Out"]  # 4
main_so = ["Status_FB_Out", "Matrix_Route_Out"]  # 2

main_sp = ["Room_Name"]  # 1
main_ip = ["Default_Master_Vol", "Auto_Shutoff_Mins"]  # 2

print(f"Main: {len(main_di)} DI, {len(main_ai)} AI, {len(main_do)} DO, {len(main_ao)} AO, {len(main_so)} SO")

# ============================================================================
# Module 2: Sony_BRAVIA_Display
# ============================================================================
sony_di = [
    "PowerOn", "PowerOff",
    "Input1_Select", "Input2_Select", "Input3_Select",
    "Input4_Select", "Input5_Select", "Input6_Select",
    "Volume_Up", "Volume_Down",
    "Mute_Toggle", "Poll",
]  # 12

sony_ai = ["Volume_Level"]  # 1
sony_bi = ["SerialIn"]  # 1

sony_do = [
    "Power_On_FB", "Power_Off_FB",
    "Input1_FB", "Input2_FB", "Input3_FB",
    "Input4_FB", "Input5_FB", "Input6_FB",
    "Mute_FB", "Comms_OK",
]  # 10

sony_ao = ["Volume_FB"]  # 1
sony_so = ["SerialOut"]  # 1

sony_sp = ["DisplayID"]  # 1
sony_ip = ["Poll_Interval_Sec", "Power_On_Warmup_MS"]  # 2

print(f"Sony: {len(sony_di)} DI, {len(sony_ai)} AI, {len(sony_bi)} BI, {len(sony_do)} DO, {len(sony_ao)} AO, {len(sony_so)} SO")

# ============================================================================
# Module 3: AVER_CAM570_PTZ
# ============================================================================
aver_di = [
    "Pan_Left", "Pan_Right",
    "Tilt_Up", "Tilt_Down",
    "Zoom_In", "Zoom_Out",
    "Focus_Far", "Focus_Near",
    "Focus_Auto",
    "Preset_1_Recall", "Preset_2_Recall",
    "Preset_3_Recall", "Preset_4_Recall",
    "Preset_Save",
    "AutoTrack_Toggle",
    "Home_Position",
]  # 16

aver_ai = ["Pan_Speed", "Tilt_Speed", "Preset_Save_Slot"]  # 3
aver_bi = ["SerialIn"]  # 1

aver_do = [
    "AutoTrack_FB",
    "Preset1_Active_FB", "Preset2_Active_FB",
    "Preset3_Active_FB", "Preset4_Active_FB",
    "Moving_FB",
]  # 6

aver_ao = ["Pan_Pos_FB", "Tilt_Pos_FB", "Zoom_Pos_FB"]  # 3
aver_so = ["SerialOut", "HTTP_Cmd_Out"]  # 2

aver_sp = ["Camera_IP"]  # 1
aver_ip = ["Default_Pan_Speed", "Default_Tilt_Speed", "Camera_Address"]  # 3

print(f"AVER: {len(aver_di)} DI, {len(aver_ai)} AI, {len(aver_bi)} BI, {len(aver_do)} DO, {len(aver_ao)} AO, {len(aver_so)} SO")

# ============================================================================
# Module 4: Shure_MXA920_DSP
# ============================================================================
shure_di = [
    "Mic1_Mute_On", "Mic1_Mute_Off",
    "Mic2_Mute_On", "Mic2_Mute_Off",
    "Mic1_Mute_Toggle", "Mic2_Mute_Toggle",
    "NetMuteBtn_Enable", "NetMuteBtn_Disable",
    "Zone1_On", "Zone1_Off",
    "Zone2_On", "Zone2_Off",
    "All_Mute_On", "All_Mute_Off",
    "DSP_Preset_Meeting", "DSP_Preset_Presentation",
    "DSP_Preset_VideoCall", "DSP_Preset_Mute",
    "ANIUSB_Enable", "ANIUSB_Disable",
    "Poll_All",
]  # 21

shure_ai = ["Mic1_Gain", "Mic2_Gain", "Master_Volume", "Zone1_Volume", "Zone2_Volume"]  # 5
shure_bi = ["TCP_In"]  # 1

shure_do = [
    "Mic1_Muted_FB", "Mic2_Muted_FB",
    "Zone1_On_FB", "Zone2_On_FB",
    "All_Muted_FB", "NetMute_Active_FB",
    "DSP_Online_FB", "ANIUSB_Online_FB",
]  # 8

shure_ao = ["Mic1_Level_FB", "Mic2_Level_FB"]  # 2
shure_so = ["TCP_Out"]  # 1

shure_sp = [
    "MXA920_A_DeviceID", "MXA920_B_DeviceID",
    "ComputeDSP_DeviceID",
    "MXNGW_Z1_DeviceID", "MXNGW_Z2_DeviceID",
    "ANIUSB_DeviceID", "NetMuteBtn_DeviceID",
]  # 7
shure_ip = ["Poll_Interval_Sec"]  # 1

print(f"Shure: {len(shure_di)} DI, {len(shure_ai)} AI, {len(shure_bi)} BI, {len(shure_do)} DO, {len(shure_ao)} AO, {len(shure_so)} SO")

# ============================================================================
# Generate all USH files
# ============================================================================
modules = [
    {
        "name": "ASMO_Boardroom_Main",
        "usp": "ASMO_Boardroom_Main.usp",
        "hint": "Main logic for ASMO Boardroom AV system",
        "category": "9",
        "di": main_di, "ai": main_ai, "bi": main_bi,
        "do": main_do, "ao": main_ao, "so": main_so,
        "sp": main_sp, "ip": main_ip,
    },
    {
        "name": "Sony_BRAVIA_Display_v2",
        "usp": "Sony_BRAVIA_Display.usp",
        "hint": "Sony BRAVIA 98B253L RS-232/IP Control Driver",
        "category": "11",
        "di": sony_di, "ai": sony_ai, "bi": sony_bi,
        "do": sony_do, "ao": sony_ao, "so": sony_so,
        "sp": sony_sp, "ip": sony_ip,
    },
    {
        "name": "AVER_CAM570_PTZ_v2",
        "usp": "AVER_CAM570_PTZ.usp",
        "hint": "AVER CAM570 PTZ Camera - VISCA over UDP",
        "category": "12",
        "di": aver_di, "ai": aver_ai, "bi": aver_bi,
        "do": aver_do, "ao": aver_ao, "so": aver_so,
        "sp": aver_sp, "ip": aver_ip,
    },
    {
        "name": "Shure_MXA920_DSP_v2",
        "usp": "Shure_MXA920_DSP.usp",
        "hint": "Shure MXA920 + Compute DSP + MXNGW-C Control API Driver",
        "category": "9",
        "di": shure_di, "ai": shure_ai, "bi": shure_bi,
        "do": shure_do, "ao": shure_ao, "so": shure_so,
        "sp": shure_sp, "ip": shure_ip,
    },
]

for mod in modules:
    ush_content = build_ush(
        name=mod["name"],
        usp_filename=mod["usp"],
        hint=mod["hint"],
        category=mod["category"],
        digital_inputs=mod["di"],
        analog_inputs=mod["ai"],
        buffer_inputs=mod["bi"],
        digital_outputs=mod["do"],
        analog_outputs=mod["ao"],
        string_outputs=mod["so"],
        string_params=mod["sp"],
        int_params=mod["ip"],
    )

    ush_filename = mod["usp"].replace(".usp", ".ush")
    ush_path = os.path.join(USH_DIR, ush_filename)

    with open(ush_path, 'w', encoding='utf-8') as f:
        f.write(ush_content)

    size = os.path.getsize(ush_path)
    print(f"  Written: {ush_path} ({size} bytes)")

print(f"\n=== ALL USH FILES WRITTEN TO {USH_DIR} ===")
print(f"Now copy them to: {DEST_DIR}")
print("Run this in an elevated command prompt:")
for mod in modules:
    fn = mod["usp"].replace(".usp", ".ush")
    src = os.path.join(USH_DIR, fn)
    dst = os.path.join(DEST_DIR, fn)
    print(f'  copy /Y "{src}" "{dst}"')
