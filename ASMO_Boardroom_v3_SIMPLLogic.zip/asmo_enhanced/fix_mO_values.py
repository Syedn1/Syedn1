import re

smw_path = r"C:\Users\12517\Downloads\ASMO_Boardroom.smw"

with open(smw_path, 'r', encoding='ascii', errors='replace') as f:
    content = f.read()

# Fix mO values for each SIMPL+ module
# The mO field counts ONLY list2 outputs (analog + serial), NOT digital outputs
# n1O counts digital outputs, tO = n1O + mO

fixes = [
    # (handle, old_mO, new_mO, name)
    (801, 29, 6, "Main"),
    (802, 10, 2, "Sony1"),
    (803, 10, 2, "Sony2"),
    (804, 6, 5, "AVER1"),
    (805, 6, 5, "AVER2"),
    (806, 8, 3, "Shure"),
]

for h, old_mo, new_mo, name in fixes:
    # Find the Sm block for this handle and fix mO
    # Pattern: within the block starting with H=<h>, find mO=<old> and replace
    # We need to be precise - only match mO within the correct Sm block

    # Strategy: find "H=<h>\n" followed by "SmC=103" (SIMPL+ module),
    # then find "mO=<old>" within that block

    pattern = r'(ObjTp=Sm\nH=' + str(h) + r'\nSmC=103\n.*?)mO=' + str(old_mo) + r'\n'
    match = re.search(pattern, content, re.DOTALL)
    if match:
        old_text = match.group(0)
        new_text = old_text.replace(f'mO={old_mo}\n', f'mO={new_mo}\n')
        content = content.replace(old_text, new_text)
        print(f"Fixed H={h} ({name}): mO={old_mo} -> {new_mo}")
    else:
        # Try alternate: mO might not be immediately after the block header
        # Search more broadly
        block_start = content.find(f'ObjTp=Sm\nH={h}\nSmC=103\n')
        if block_start >= 0:
            block_end = content.find('\n[', block_start + 10)
            block = content[block_start:block_end]
            old_mo_str = f'mO={old_mo}\n'
            if old_mo_str in block:
                new_block = block.replace(old_mo_str, f'mO={new_mo}\n')
                content = content[:block_start] + new_block + content[block_end:]
                print(f"Fixed H={h} ({name}): mO={old_mo} -> {new_mo} (alt)")
            else:
                # Check current mO value
                mo_match = re.search(r'mO=(\d+)', block)
                if mo_match:
                    cur = mo_match.group(1)
                    if cur == str(new_mo):
                        print(f"H={h} ({name}): mO already correct ({new_mo})")
                    else:
                        print(f"H={h} ({name}): mO={cur} (unexpected, fixing to {new_mo})")
                        content = content[:block_start] + block.replace(f'mO={cur}\n', f'mO={new_mo}\n') + content[block_end:]
                else:
                    print(f"H={h} ({name}): mO field not found in block!")
        else:
            print(f"H={h} ({name}): Block not found!")

with open(smw_path, 'w', encoding='ascii', errors='replace') as f:
    f.write(content)

print("\nDone. mO values fixed.")
